from flask import *
import re
from flask_mysqldb import MySQL
from flask_recaptcha import ReCaptcha
import smtplib
import random
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

app = Flask(__name__)

app.config['MYSQL_USER'] = 'adminkz'
app.config['MYSQL_PASSWORD'] = 'password'
app.config['MYSQL_HOST'] = '127.0.0.1'
app.config['MYSQL_PORT'] = 8889
app.config['MYSQL_DB'] = 'esential'

app.secret_key = 'my site niga'


app.config['RECAPTCHA_SITE_KEY'] = '6LdT_E8dAAAAAH47gZAmLI9vsDzNAihIYdqxkg86'
app.config['RECAPTCHA_SECRET_KEY'] = '6LdT_E8dAAAAAGw9iL3HGKVR8bit-qB9HX-eV-Zh'
recaptcha = ReCaptcha(app)

MY_ADDRESS = 'essence.bottles@gmail.com'

s = smtplib.SMTP(host='smtp.gmail.com', port=587)
s.starttls()
s.login(MY_ADDRESS, '2003Aspan')




mysql = MySQL(app)

@app.route("/")
def index():
    return render_template('index.html')

@app.route('/bottles/')
def bottles():
    mainarr = [['none', 'img/noava.png'], 
    ['nan', 'img/noava.png'], 
    ['none', 'img/noava.png'], 
    ['nan', 'img/noava.png'], 
    ['none', 'img/noava.png'], 
    ['nan', 'img/noava.png'], 
    ['none', 'img/noava.png'],
    ['nan', 'img/noava.png'], 
    ['none', 'img/noava.png']]
    cur = mysql.connection.cursor()

    for x in range(9):
        if (cur.execute("SELECT price FROM Bottles WHERE ID=" + str(x + 1))):
            mainarr[x][0] = str(re.sub('\W', '', str(cur.fetchall())) + " ₸ 🇰🇿")
            if (cur.execute("SELECT img_path FROM Bottles WHERE ID=" + str(x + 1))):
                mainarr[x][1] = str(re.sub("\(*\)*\,*\'*", '', str(cur.fetchall())))
                if (mainarr[x][1] == "None"):
                    mainarr[x][1] = "img/no-image.png"
        else:
            mainarr[x][0] = "Item not available"

    debugg = None
    prodex = ["Dont touch this!"]


    return render_template('bottles_page.html', prod1 = mainarr[0], prod2 = mainarr[1], prod3 = mainarr[2], prod4 = mainarr[3], prod5 = mainarr[4], prod6 = mainarr[5], prod7 = mainarr[6], prod8 = mainarr[7], prod9 = mainarr[8], prodex = prodex, debugg = debugg)
@app.route('/about/')
def about():
    return render_template('about_page.html')

@app.route('/logout/')
def logout():
    session.pop('logged_in', None)
    return redirect(url_for('index'))

@app.route('/login/', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        if request.form['username'] == "" or request.form['pass'] == "":
            error = "Please insert correct values"
        else:
            loginn = request.form['username']
            passn = request.form['pass']
            cur = mysql.connection.cursor()
            if (cur.execute("SELECT login FROM Users WHERE login='"  + loginn + "' AND pass='" + passn + "'")):
                uname = str(re.sub('\W', '', str(cur.fetchall())))
                cur.close()
                session['logged_in'] = True
                return render_template('index.html', uname = uname)
            else:
                error = "Login or password is incorrect"

    return render_template('login.html', error = error)
@app.route('/signup/', methods=['GET', "POST"])
def signup():
    error = None
    if request.method == 'POST':
        if request.form['login'] == "" or request.form['pass'] == "" or request.form['mail'] == "":
            error = "Please enter non-empty values"
        else:
            loginn = request.form['login']
            passn = request.form['pass']
            mailn = request.form['mail']
            cur = mysql.connection.cursor()
            if (cur.execute("SELECT login FROM Users WHERE login='"  + loginn + "' OR email='" + mailn + "'")):
                error = "A user with this nickname or email already exists"
            else:
                cur.execute("INSERT INTO Users(login, email, pass) VALUES ('" + loginn + "', '" + mailn + "', '" + passn + "')")
                mysql.connection.commit()

                msg = MIMEMultipart()


                sub_msg_code = "Thank you for registering in our service for the sale of ecological bottles! We wish you an active and healthy lifestyle. With love, the Essence-Bottles team"

                msg['From']=MY_ADDRESS
                msg['To']=mailn
                msg['Subject']="Welcome to Essence-Bottles"

                msg.attach(MIMEText(sub_msg_code, 'plain'))

                s.send_message(msg)
    
                del msg

                error = "Registration is successful, you can login to the site"
                return redirect(url_for('login'))

                cur.close()

    return render_template('signup.html', error = error)

@app.route('/reset/', methods=['GET', 'POST'])
def reset():
    message = '' # Create empty message
    if request.method == 'POST': # Check to see if flask.request.method is POST
        if recaptcha.verify(): # Use verify() method to see if ReCaptcha is filled out
            cur = mysql.connection.cursor()
            if (cur.execute("SELECT email FROM Users WHERE email='" + request.form['mail'] + "'")):

                
                msg = MIMEMultipart()

                nums = "0123456789"
                length = 6

                sub_msg_code = "".join(random.sample(nums, length))

                cur.execute("INSERT INTO codes(vcode, email) VALUES ('" + sub_msg_code + "','" + request.form['mail'] + "')")
                mysql.connection.commit()
                cur.close()

                msg['From']=MY_ADDRESS
                msg['To']=request.form['mail']
                msg['Subject']= "Verify code"

                msg.attach(MIMEText(sub_msg_code, 'plain'))

                s.send_message(msg)
    
                del msg

                cur.close()
                return redirect(url_for('verify'))
            else:
                message = "We can't find your email!"
        else:
            message = 'Please fill out the ReCaptcha!' # Send error message
    return render_template('remember.html', message=message)

@app.route('/verify/', methods=['GET', 'POST'])
def verify():
    error = None
    if request.method == 'POST':
        cur = mysql.connection.cursor()
        if (cur.execute("SELECT email FROM codes WHERE vcode='" + request.form['code'] + "'")):
            mailn = str(re.sub("\(*\)*\,*\'*", '', str(cur.fetchall())))
            if (cur.execute("SELECT pass FROM Users WHERE email='"  + mailn + "'")):
                passw = str(re.sub('\W', '', str(cur.fetchall())))
                
                msg = MIMEMultipart()


                sub_msg_code = "Your password is '" + passw + "'"

                msg['From']=MY_ADDRESS
                msg['To']=mailn
                msg['Subject']="Reset password in Essence-Bottles"

                msg.attach(MIMEText(sub_msg_code, 'plain'))

                s.send_message(msg)
    
                del msg

                cur.execute("DELETE FROM codes WHERE vcode='" + request.form['code'] + "'")
                mysql.connection.commit()
                cur.close()
                return redirect(url_for('login'))
        else:
            error = "The code isn't correct!"
    return render_template('verify.html', error = error)


@app.route('/adminka/')
def adminka():
    return render_template('adminPan.html')




@app.route('/editItemsa/', methods=['GET', "POST"])
def editItemsa():
    cur = mysql.connection.cursor()
    ids = ['ID']
    names = ['Name']
    prices = ['Price']
    avlbs = ['Available']
    imgs = ['IMG']

    cur.execute("SELECT count(status) FROM Bottles")

    lenth = int(nosym(cur.fetchall()))

    for x in range(0, 10):
        if (cur.execute("SELECT id FROM Bottles WHERE id = " + str(x) + ";")):
            ids.append(nosym(cur.fetchall()))
        else:
            pass
    for x in range(0, 10):
        if (cur.execute("SELECT name FROM Bottles WHERE id = " + str(x) + ";")):
            names.append(nosym(cur.fetchall()))
        else:
            pass
    for x in range(0, 10):
        if (cur.execute("SELECT price FROM Bottles WHERE id = " + str(x) + ";")):
            prices.append(nosym(cur.fetchall()))
        else:
            pass
    for x in range(0, 10):
        if (cur.execute("SELECT status FROM Bottles WHERE id = " + str(x) + ";")):
            avlbs.append(nosym(cur.fetchall()))
        else:
            pass
    for x in range(0, 10):
        if (cur.execute("SELECT img_path FROM Bottles WHERE id = " + str(x) + ";")):
            imgs.append(nosym(cur.fetchall()))
        else:
            pass

    error = None
    if request.method == 'POST':
        if request.form['nama'] == "" or request.form['imp'] == "":
            error = "Error! Please enter non-empty values"
        else:
            if request.form['nama'] == " " or request.form['imp'] == " ":
                error = "Error! Please enter non-empty values"
            else:
                ida = request.form['idy']
                nama = request.form['nama']
                pric = request.form['price']
                ava = request.form['ava']
                imp = request.form['imp']
                if (cur.execute("INSERT INTO Bottles VALUES (" + ida +", '" + nama + "', " + pric + "," + ava + ",'" + imp + "'" +")")):
                    error = "Good!"
                    mysql.connection.commit()
                    return redirect(url_for('editItemsa'))
                else:
                    error = "Something went wrong"


    return render_template('editkap.html', len = lenth, ids = ids, name = names, price = prices, avlb = avlbs, imga = imgs, error = error)
    #


@app.route('/editItemsb/', methods=['GET', "POST"])
def editItemsb():
    cur = mysql.connection.cursor()
    ids = ['ID']
    names = ['Name']
    prices = ['Price']
    avlbs = ['Available']
    imgs = ['IMG']

    error = None

    cur.execute("SELECT count(status) FROM Bottles")

    lenth = int(nosym(cur.fetchall()))

    for x in range(0, 10):
        if (cur.execute("SELECT id FROM Bottles WHERE id = " + str(x) + ";")):
            ids.append(nosym(cur.fetchall()))
        else:
            pass
    for x in range(0, 10):
        if (cur.execute("SELECT name FROM Bottles WHERE id = " + str(x) + ";")):
            names.append(nosym(cur.fetchall()))
        else:
            pass
    for x in range(0, 10):
        if (cur.execute("SELECT price FROM Bottles WHERE id = " + str(x) + ";")):
            prices.append(nosym(cur.fetchall()))
        else:
            pass
    for x in range(0, 10):
        if (cur.execute("SELECT status FROM Bottles WHERE id = " + str(x) + ";")):
            avlbs.append(nosym(cur.fetchall()))
        else:
            pass
    for x in range(0, 10):
        if (cur.execute("SELECT img_path FROM Bottles WHERE id = " + str(x) + ";")):
            imgs.append(nosym(cur.fetchall()))
        else:
            pass


    if request.method == 'POST':
        idas = request.form['idy']

        if (cur.execute("DELETE FROM Bottles WHERE id=" + idas)):
            mysql.connection.commit()
            return redirect(url_for('editItemsb'))


    return render_template('editkam.html', len = lenth, ids = ids, name = names, price = prices, avlb = avlbs, imga = imgs, error = error)



def nosym(requ):
    return str(re.sub("\(*\)*\,*\'*", '', str(requ)))

if __name__ == "__main__":
    app.run(debug=True, port=5002)